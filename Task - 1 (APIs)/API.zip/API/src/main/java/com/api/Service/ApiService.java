package com.api.Service;


public interface ApiService {
	
	public String returnString(String name);
	public String palindrome(String str);
}
